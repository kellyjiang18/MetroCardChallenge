public class ReducedFareMetroCard extends MetroCard
{
    // INSTANCE VARIABLES (if any)

    // CONSTRUCTOR(S)
    public ReducedFareMetroCard(double bal)
    {
        super(bal);
        setFareCost(1.35);
    }


    // METHODS (if any), including overridden methods


}
